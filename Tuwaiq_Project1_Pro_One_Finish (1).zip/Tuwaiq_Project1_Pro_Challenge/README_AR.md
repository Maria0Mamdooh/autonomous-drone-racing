# Tuwaiq Project 1 PRO — One Continuous Race / سباق متواصل

هذه نسخة معدلة من نفس مضمار **PRO Challenge**. تم حذف المنصة الصفراء الوسطية من نسختي Gazebo ومن ملف البناء؛ توجد **نقطة انطلاق واحدة خضراء** و**نقطة هبوط واحدة صفراء في النهاية**.

## المهمة

START → G1 → G2 → G3 → G4 → G5 → G6 → FINISH → LAND (مرة واحدة فقط).

- ست بوابات متدرجة الارتفاع والاتجاه (G1=2.55م, G2=3.85م, G3=2.25م, G4=4.45م, G5=2.35م, G6=3.40م).
- المسار تقريبيًا 92 متر بدون Loop.
- لا يوجد `--practice` أو منصة تدريب وسط المسار.
- كل نقطة قبل الأخيرة تستخدم **Fly-through**؛ فقط عند نهاية السباق يصدر `action.land()`.
- البيانات الظاهرة في الطرفية: الارتفاع والسرعة والبطارية.

## التثبيت (داخل Ubuntu، الملف في Downloads)

أغلقي Gazebo وPX4 القديمين أولًا ثم:

```bash
unzip -o ~/Downloads/Tuwaiq_Project1_Pro_One_Finish.zip -d ~/
cd ~/Tuwaiq_Project1_Pro_Challenge
python3 verify_files.py
```

هذا يحدّث ملفات المشروع السابق داخل المجلد نفسه، ولا يغيّر `~/drone_racing`.

## التشغيل (أربع نوافذ Terminal)

```bash
# Terminal 1
cd ~/Tuwaiq_Project1_Pro_Challenge
bash 01_gazebo.sh lite
```

```bash
# Terminal 2
cd ~/Tuwaiq_Project1_Pro_Challenge
bash 02_px4.sh
```

```bash
# Terminal 3
cd ~/Tuwaiq_Project1_Pro_Challenge
bash 03_qgc.sh
```

```bash
# Terminal 4 — Continuous full race
cd ~/Tuwaiq_Project1_Pro_Challenge
bash 04_project1.sh --challenge --speed 0.8
```

بعد رفع المهمة، راجعي Plan في QGroundControl وحالة Ready To Fly وأخطاء الحساسات. عند ظهور `Type START` اكتبي START فقط إذا كانت الجاهزية سليمة.

**تنبيه:** تجربة حركة الدرون في VMware لم تُختبر هنا. Waypoints ليست دليلًا قاطعًا على عبور جميع البوابات. إذا ظهر `Attitude failure` أو `Accelerometer Timeout` لا تستخدمي Force Arm؛ أصلحي إعداد المحاكاة أولًا.

## إعادة البناء

```bash
python3 build_world.py
python3 verify_files.py
```

العالم الكامل موجود باسم `project1_pro_full.sdf`، والخفيف `project1_pro_lite.sdf`. نفس الإحداثيات في الاثنين.
