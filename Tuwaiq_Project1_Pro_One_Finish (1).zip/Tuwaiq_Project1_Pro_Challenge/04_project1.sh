#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$HOME/drone_racing/venv/bin/python"
if [ ! -x "$PY" ]; then
 echo "Could not find your existing MAVSDK Python environment: $PY"
 echo 'Use your existing Python interpreter with mavsdk_grpc installed.'
 exit 1
fi
exec "$PY" "$DIR/mission_project1.py" "$@"
