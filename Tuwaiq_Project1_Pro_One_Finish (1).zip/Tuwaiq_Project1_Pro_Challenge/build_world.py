#!/usr/bin/env python3
"""Build the PROJECT 1 indoor challenge (real Gazebo SDF) from bundled templates.

No external Python packages required. World uses PX4 Gazebo standard physics plugins.
Coordinate convention: ENU X east (forward), Y north (left), Z up.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import math, json

BASE=Path(__file__).resolve().parent
CFG=json.loads((BASE/'track_config.json').read_text())
COLORS=[(0.05,0.84,1.0), (0.70,0.20,1.0), (0.15,0.94,0.68),
        (0.98,0.45,0.10), (1.0,0.22,0.65), (0.30,0.70,1.0)]

def child(parent, name, txt=None, attrib=None):
    e=ET.SubElement(parent,name,attrib or {})
    if txt is not None: e.text=str(txt)
    return e

def geo_box(parent,size):
    g=child(parent,'geometry'); child(child(g,'box'),'size',' '.join(f'{v:.5f}' for v in size))

def add_box(link,name,pose,size,color, collision=False, glow=False):
    # Geometry orientation is local to the model link.
    v=child(link,'visual',attrib={'name':name+'_visual'})
    child(v,'pose',' '.join(f'{v:.5f}' for v in pose))
    geo_box(v,size)
    m=child(v,'material')
    rgba=' '.join(f'{v:.3f}' for v in color)+' 1'
    child(m,'ambient',rgba);child(m,'diffuse',rgba)
    if glow:child(m,'emissive',rgba)
    if collision:
        c=child(link,'collision',attrib={'name':name+'_collision'})
        child(c,'pose',' '.join(f'{v:.5f}' for v in pose));geo_box(c,size)

def model(world,name):
    m=child(world,'model',attrib={'name':name});child(m,'static','true'); child(m,'pose','0 0 0 0 0 0')
    return m,child(m,'link',attrib={'name':'link'})

def gate_model(world,g,index):
    x,y,z=g['x_m'],g['y_m'],g['z_m']
    yaw=math.radians(g['heading_deg']); w=g['opening_width_m'];h=g['opening_height_m']
    t=0.16;side=w/2+t/2;top=h/2+t/2
    m,link=model(world, f'gate_{index:02d}')
    m.find('pose').text=f'{x:.5f} {y:.5f} {z:.5f} 0 0 {yaw:.7f}'
    color=COLORS[(index-1)%len(COLORS)]
    for s in (-1,1):
        add_box(link,f'side_{s}', (0,s*side,0,0,0,0),(t,t,h+2*t),color,True,True)
    for s in (-1,1):
        add_box(link,f'cross_{s}',(0,0,s*top,0,0,0),(t,w+2*t,t),color,True,True)
    # Supports reach the floor regardless of ring height (unlike fixed-length supports).
    frame_bottom=z-top-t/2
    support_top=max(0.19,frame_bottom)
    supp_len=max(0.11,support_top-0.12)
    supp_center=(support_top+0.12)/2-z
    for s in (-1,1):
        add_box(link,f'support_{s}', (0,s*(side+0.32),supp_center,0,0,0),
            (0.15,0.15,supp_len),(0.24,0.30,0.42),True)
        add_box(link,f'foot_{s}',(0,s*(side+0.32),0.10-z,0,0,0),
            (0.48,0.48,0.20),(0.24,0.30,0.42),True)
    # visual contrast marks; no extra collision
    for s in (-1,1):
        add_box(link,f'check_{s}',(0,s*(side+0.03),top+0.06,0,0,0),
             (0.23,0.36,0.10),(0.93,0.95,1.0),False)
    return m

def lane(world,full):
    m,l=model(world,'challenge_race_surface')
    cl=CFG['ground_centerline']
    for i,(a,b) in enumerate(zip(cl,cl[1:])):
        dx=b[0]-a[0];dy=b[1]-a[1]; ang=math.atan2(dy,dx)
        le=math.hypot(dx,dy);cx=(a[0]+b[0])/2;cy=(a[1]+b[1])/2
        add_box(l,f'tarmac_{i}',(cx,cy,0.012,0,0,ang),
                (le+0.22,CFG['lane_width_m'],0.024),(0.09,0.12,0.18))
        for side in (-1,1):
            # visual-only neon boundary, outside the flight corridor
            xx=cx-math.sin(ang)*side*(CFG['lane_width_m']/2+0.13)
            yy=cy+math.cos(ang)*side*(CFG['lane_width_m']/2+0.13)
            add_box(l,f'edge_{side}_{i}',(xx,yy,0.05,0,0,ang),
                    (le,0.13,0.03),(0.02,0.70,1.0),False,True)
        if i%2==0:
            add_box(l,f'dash_{i}',(cx,cy,0.045,0,0,ang),
                    (min(2.4,le*0.6),0.08,0.024),(0.20,0.50,0.76))
    # START pad and ONE FINISH pad only; no intermediate training landing.
    for name,key,tint in [('start','start',(0.05,0.88,0.62)),
                          ('finish','finish',(0.96,0.73,0.15))]:
        p=CFG[key];xx,yy=p['x'],p['y']
        add_box(l,f'{name}_pad',(xx,yy,0.062,0,0,0),
                (3.0,3.0,0.035),tint,False,True)
        add_box(l,f'{name}_inner',(xx,yy,0.084,0,0,0),
                (2.2,2.2,0.015),(0.04,0.085,0.13))
    # timed slalom-style floor chevrons (visual-only, not navigation beacons)
    if full:
        for i,g in enumerate(CFG['gates']):
            xx=g['x_m']-5;yy=g['y_m']
            add_box(l,f'gate_marker_{i}',(xx,yy,0.067,0,0,math.radians(g['heading_deg'])),
                    (0.48,1.2,0.02),COLORS[i],False,True)
    return m

def build(mode):
    worldtree=ET.parse(BASE/'templates'/f'base_{mode}.sdf')
    world=worldtree.getroot().find('world')
    world.set('name',CFG['world_name'])
    remove=('racing_lane','course_markers')
    for m in list(world.findall('model')):
        if m.get('name','').startswith('gate_') or m.get('name') in remove:
            world.remove(m)
    lane(world, mode=='full')
    for i,g in enumerate(CFG['gates'],1):gate_model(world,g,i)
    ET.indent(worldtree,space='  ')
    path=BASE/f'project1_pro_{mode}.sdf'
    worldtree.write(path,encoding='utf-8',xml_declaration=True)
    print('WROTE',path, path.stat().st_size,'bytes')

if __name__=='__main__':
    for mode in ('lite','full'):build(mode)
