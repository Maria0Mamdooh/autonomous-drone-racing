#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-lite}"
case "$MODE" in
 lite) WORLD="$DIR/project1_pro_lite.sdf";;
 full) WORLD="$DIR/project1_pro_full.sdf";;
 *) echo 'Usage: bash 01_gazebo.sh [lite|full]'; exit 2;;
esac
export GZ_SIM_RESOURCE_PATH="$DIR:$HOME/PX4-Autopilot/Tools/simulation/gz/models:${GZ_SIM_RESOURCE_PATH:-}"
echo "Starting Tuwaiq PRO indoor arena ($MODE, 6 gates, no loop)"
gz sim -r "$WORLD"
