#!/usr/bin/env bash
set -euo pipefail
flatpak run org.mavlink.qgroundcontrol
