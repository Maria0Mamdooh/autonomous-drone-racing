#!/usr/bin/env python3
"""Offline checks only. Does not claim Gazebo or PX4 flight was tested."""
import json,math,xml.etree.ElementTree as ET
from pathlib import Path
BASE=Path(__file__).resolve().parent
C=json.loads((BASE/'track_config.json').read_text())
assert len(C['gates'])==6
assert C['track_type'].find('no loop')>=0
assert 'practice_finish' not in C
for mode in ('lite','full'):
    f=BASE/f'project1_pro_{mode}.sdf'
    world=ET.parse(f).getroot().find('world')
    assert world is not None and world.get('name')==C['world_name']
    gates=sorted([m for m in world.findall('model') if m.get('name','').startswith('gate_')],key=lambda e:e.get('name'))
    assert len(gates)==6
    assert world.find("plugin[@filename='gz-sim-imu-system']") is not None
    lane=world.find("model[@name='challenge_race_surface']")
    assert lane is not None
    names=[v.get('name') for v in lane.findall('.//visual')]
    assert len([name for name in names if name.endswith('_pad_visual')])==2, names
    assert 'start_pad_visual' in names and 'finish_pad_visual' in names
    assert not any('practice' in name for name in names)
    for gate,meta in zip(gates,C['gates']):
        pos=list(map(float,gate.findtext('pose').split()))
        assert abs(pos[0]-meta['x_m'])<1e-4 and abs(pos[1]-meta['y_m'])<1e-4
        assert abs(pos[2]-meta['z_m'])<1e-4
        assert abs(math.degrees(pos[-1])-meta['heading_deg'])<0.001
        assert len(gate.findall('.//collision'))==8
        # Bottom opening clearance; lower frame above the floor.
        lower=meta['z_m']-meta['opening_height_m']/2-0.16
        assert lower>0.55, (meta['id'],lower)
        assert 3.0<=meta['opening_width_m']<=4.0
    print('PASS:',f.name,'6 gates, solid frame collisions, positive floor clearance')

code=(BASE/'mission_project1.py').read_text()
compile(code,'mission_project1.py','exec')
assert len(C['gates']) == 6 and C['gates'][4]['opening_width_m'] < C['gates'][0]['opening_width_m']
assert abs(C['finish']['x']-C['start']['x'])>80
assert C['gates'][3]['z_m']>4 and C['gates'][2]['z_m']<2.5
assert any(g['y_m']>2.5 for g in C['gates'])
assert any(g['y_m']<-2.5 for g in C['gates'])
print('PASS: 6 varied gates; ONE finish landing pad; full continuous race mission compiles')
print('NOTE: Gazebo physics and PX4 mission are NOT live-tested here.')
