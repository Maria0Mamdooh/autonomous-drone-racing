#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export GZ_SIM_RESOURCE_PATH="$DIR:$HOME/PX4-Autopilot/Tools/simulation/gz/models:${GZ_SIM_RESOURCE_PATH:-}"
cd "$HOME/PX4-Autopilot"
echo 'Connecting PX4 x500 to existing world tuwaiq_p1_pro'
PX4_GZ_STANDALONE=1 PX4_GZ_WORLD=tuwaiq_p1_pro PX4_GZ_MODEL_POSE="0,0,0.15,0,0,0" make px4_sitl gz_x500
