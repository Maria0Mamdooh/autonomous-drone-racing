#!/usr/bin/env python3
"""Tuwaiq Project 1 PRO — six gates, high/low slalom, telemetry and landing.

Waypoint BASELINE for simulation only. Does NOT perform vision-based navigation
or prove that the aircraft physically cleared each gate.

Usage: python mission_project1.py [--challenge] [--speed 0.9]
"""
import argparse
import asyncio
import json
import math
import time
from pathlib import Path

from mavsdk_grpc import System
from mavsdk_grpc.mission import MissionItem, MissionPlan

CFG = json.loads((Path(__file__).resolve().parent/'track_config.json').read_text())
LAT0 = CFG['origin_gps']['latitude_deg']
LON0 = CFG['origin_gps']['longitude_deg']
EARTH_R = 6378137.0
NAN = float('nan')


def to_gps(x, y):
    """For this ~100 m environment only: Gazebo local ENU -> WGS84 approx."""
    return (LAT0 + math.degrees(y / EARTH_R),
            LON0 + math.degrees(x / (EARTH_R * math.cos(math.radians(LAT0)))))


def horizontal_distance(lat_a, lon_a, lat_b, lon_b):
    north = math.radians(lat_a - lat_b) * EARTH_R
    east = math.radians(lon_a - lon_b) * EARTH_R * math.cos(math.radians(lat_b))
    return math.hypot(north, east)


def make_waypoints():
    """Six gates in sequence; fly-through approach/center/exit at each one.

    Exactly ONE landing pad at the end. No intermediate landing or pause.
    """
    points = [(5.0, 0.0, 2.4)]
    for g in CFG['gates']:
        angle = math.radians(g['heading_deg'])
        ux, uy = math.cos(angle), math.sin(angle)
        x, y, z = g['x_m'], g['y_m'], g['z_m']
        points.extend([
            (x - 4.3 * ux, y - 4.3 * uy, z),
            (x, y, z),
            (x + 3.4 * ux, y + 3.4 * uy, z),
        ])
    land = CFG['finish']
    points.extend([(86.5, 0.4, 2.8), (land['x'], land['y'], 2.4)])
    return points, land


def make_mission(points, speed):
    items=[]
    for i, (x,y,z) in enumerate(points):
        lat,lon = to_gps(x,y)
        items.append(MissionItem(
            lat, lon,
            z - CFG['start']['spawn_z'],  # mission relative-to-launch altitude
            speed,
            i != len(points)-1,         # fly-through except final waypoint
            NAN,NAN,
            MissionItem.CameraAction.NONE,
            NAN,NAN,
            0.45,                      # waypoint acceptance radius, metres
            NAN,NAN,
            MissionItem.VehicleAction.NONE,
        ))
    return MissionPlan(items)


async def first(stream):
    async for sample in stream:
        return sample
    raise RuntimeError('Telemetry stream terminated')


async def wait_global_position(drone, timeout):
    async def probe():
        async for h in drone.telemetry.health():
            if h.is_global_position_ok and h.is_home_position_ok:
                return True
    try:
        await asyncio.wait_for(probe(), timeout)
        return True
    except asyncio.TimeoutError:
        return False


async def report_telemetry(drone):
    try:
        while True:
            p=await first(drone.telemetry.position())
            v=await first(drone.telemetry.velocity_ned())
            b=await first(drone.telemetry.battery())
            speed=math.hypot(v.north_m_s,v.east_m_s)
            print(f'TELEMETRY | ALT {p.relative_altitude_m:.2f} m | '
                  f'SPEED {speed:.2f} m/s | BATTERY {b.remaining_percent*100:.0f}%')
            await asyncio.sleep(2.5)
    except asyncio.CancelledError:
        raise
    except Exception as error:
        print('Telemetry stream issue:', error)


async def main():
    ap=argparse.ArgumentParser(description='Tuwaiq Project 1 PRO simulation')
    ap.add_argument('--challenge',action='store_true',help='same as default: full 6-gate continuous race')
    ap.add_argument('--speed',type=float,default=0.9,help='speed m/s (0.5–1.3)')
    args=ap.parse_args()
    if not 0.5 <= args.speed <= 1.3: ap.error('Speed must be 0.5..1.3 m/s')
    count=6
    points,landing=make_waypoints()
    print(f'PROJECT 1 — PRO CHALLENGE | {count} gates | {len(points)} mission items | speed={args.speed}m/s')
    drone=System()
    print('Connecting to PX4...')
    await drone.connect(system_address='udpin://0.0.0.0:14540')
    async def connection():
        async for state in drone.core.connection_state():
            if state.is_connected:return True
    try:
        await asyncio.wait_for(connection(), 45)
    except asyncio.TimeoutError:
        print('PX4 not connected; keep Gazebo+PX4 running.');return
    print('Connected. Waiting for GPS and Home...')
    if not await wait_global_position(drone,90):
        print('GPS/HOME unavailable. Check simulation; do not bypass preflight checks.');return
    if await first(drone.telemetry.in_air()):
        print('Drone is already airborne; land it first.');return
    pos=await first(drone.telemetry.position())
    slat,slon=to_gps(CFG['start']['x'],CFG['start']['y'])
    if horizontal_distance(pos.latitude_deg,pos.longitude_deg,slat,slon)>5:
        print('Drone is not at starting point; reset simulation first.');return

    print('Uploading waypoint mission...')
    await drone.mission.set_return_to_launch_after_mission(False)
    await drone.mission.upload_mission(make_mission(points,args.speed))
    print(f'MISSION UPLOADED: {len(points)} items, {count} gates, ONE landing at finish.')
    print('Fly-through all gates without intermediate landing.')
    print('Inspect route in QGroundControl; confirm READY TO FLY and no sensor/attitude warnings.')
    print('Waypoint arrival does NOT guarantee physical gate crossing.')
    if input('Type START to fly in Gazebo: ').strip().upper() != 'START':
        print('Cancelled.'); return
    if not await wait_global_position(drone,30):
        print('GPS/ Home lost; cancelled.');return
    if await first(drone.telemetry.in_air()):
        print('Already airborne; cancelled.');return

    print('Arming and starting mission...')
    await drone.action.arm()
    await drone.mission.start_mission()
    reporter=asyncio.create_task(report_telemetry(drone))
    started=time.monotonic()
    try:
        timeout=420
        for tick in range(timeout):
            if await drone.mission.is_mission_finished(): break
            await asyncio.sleep(1)
        else:
            print('Mission timed out: monitor QGroundControl and land safely.');return
        pos=await first(drone.telemetry.position())
        lat,lon=to_gps(landing['x'],landing['y'])
        dist=horizontal_distance(pos.latitude_deg,pos.longitude_deg,lat,lon)
        print(f'Waypoints completed. Distance to landing point: {dist:.2f}m')
        if dist>3:
            print('Drone not near landing pad: no automatic landing issued. Inspect in QGC.');return
        print('Landing...')
        await drone.action.land()
        for _ in range(90):
            if not await first(drone.telemetry.in_air()):
                print(f'LANDING CONFIRMED | elapsed {time.monotonic()-started:.1f}s')
                print('Note: gate aperture passage not independently verified.')
                return
            await asyncio.sleep(1)
        print('Landing was not confirmed; check QGC.')
    finally:
        reporter.cancel()
        await asyncio.gather(reporter, return_exceptions=True)

if __name__=='__main__':
    try: asyncio.run(main())
    except Exception as error:
        print('Mission error:', error)
        print('Check Gazebo, PX4, QGroundControl and preflight status; never Force Arm.')
