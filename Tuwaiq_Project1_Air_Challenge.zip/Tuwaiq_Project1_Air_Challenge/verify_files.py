#!/usr/bin/env python3
import json, xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parent
cfg=json.loads((root/'track_config.json').read_text())
assert len(cfg['gates'])==5
for n in ['project1_indoor_lite.sdf','project1_indoor_full.sdf']:
    world=ET.parse(root/n).getroot().find('world')
    gates=[m for m in world.findall('model') if m.attrib['name'].startswith('gate_')]
    assert len(gates)==5,(n,len(gates))
    assert world.attrib['name']==cfg['world_name']
    for g,c in zip(gates,cfg['gates']):
        geoms=g.findall('.//collision')
        assert len(geoms)>=6
        assert float(c['z_m'])-1.52>0.4
    print(f'PASS: {n} | 5 open-frame gates with collisions')
compile((root/'mission_project1.py').read_text(),str(root/'mission_project1.py'),'exec')
print('PASS: mission_project1.py compiles; 5 gates; route non-loop')
