#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$HOME/drone_racing/venv/bin/python"
if [ ! -x "$PY" ]; then echo "Python environment missing at $PY"; exit 1; fi
"$PY" "$DIR/mission_project1.py" "$@"
