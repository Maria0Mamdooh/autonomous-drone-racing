# Tuwaiq Project 1 — Indoor Air Challenge 🚁

**هذا Project 1 فقط، بدون Loop**. عالم Gazebo حقيقي بمضمار داخلي قصير باتجاه واحد (Start → Finish) مستوحى من صورة سباق الدرون: إضاءة زرقاء وبنفسجية، **5 بوابات مستطيلة معلقة**، ارتفاعات مختلفة، وإزاحات يمين ويسار. بدون أشجار أو زحمة ديكور.

- المضمار نحو 84 م، من (0,0) إلى (83,0)
- Gate 1: x14, y0, z2.25m
- Gate 2: x28, y+1.5, z3.35m
- Gate 3: x42, y-1.45, z2.05m
- Gate 4: x56, y+1.8, z3.65m
- Gate 5: x70, y-0.5, z2.55m
- فتحات البوابات تقريبًا 3.64 × 2.88 م لسهولة تجربة x500
- نسخة Lite للـVMware مع الإبقاء على نفس البوابات والإحداثيات والاصطدامات.

**الملفات**
`project1_indoor_lite.sdf` / `project1_indoor_full.sdf`: عالمي Gazebo. `mission_project1.py`: Mission Plan + Telemetry + automatic landing. `track_config.json` + `gate_positions.csv`: بيانات البوابات. `verify_files.py`: فحص بنية الحزمة.

## حمّلي ZIP داخل Ubuntu واشتغلي بالترتيب

افتحي Terminal في Ubuntu:

```bash
unzip -o "$HOME/Downloads/Tuwaiq_Project1_Air_Challenge.zip" -d "$HOME"
cd "$HOME/Tuwaiq_Project1_Air_Challenge"
python3 verify_files.py
```

**Terminal 1 — Gazebo** (ابدئي بالخفيف):

```bash
cd "$HOME/Tuwaiq_Project1_Air_Challenge"
bash 01_gazebo.sh lite
```

**Terminal 2 — PX4** (بعد ظهور Gazebo):

```bash
cd "$HOME/Tuwaiq_Project1_Air_Challenge"
bash 02_px4.sh
```

**Terminal 3 — QGroundControl**:

```bash
cd "$HOME/Tuwaiq_Project1_Air_Challenge"
bash 03_qgc.sh
```

**Terminal 4 — Python mission**:

```bash
cd "$HOME/Tuwaiq_Project1_Air_Challenge"
bash 04_project1.sh
```

راجعي Mission Plan في QGroundControl وتأكدي من Ready To Fly وأنه لا يوجد تحذير Accelerometer/IMU/Attitude. ثم اكتبي START للمهمة، وراقبي الطيران طول الوقت. **لا تتجاوزي فحوصات الأمان.**

### ملاحظات مهمة
- لا تشغّلين الكود القديم (`~/mission.py`) مع هذا المضمار الجديد لأنه يحوي إحداثيات مختلفة.
- PX4 SITL يستعمل عالم `tuwaiq_p1_challenge` وSpawn عند `(0,0,0.15)`.
- نجاح Waypoints لا يثبت عبور جسم الدرون من داخل كل إطار؛ اختبري الأمر بصريًا في Gazebo، ويحتاج مشروع الفاينل لاكتشاف رؤية وجهاز تحقق مستقل.
- هذا التوليد **اختُبر بنيويًا** على SDF وPython فقط. لم أشغّل Gazebo/PX4 في VMware عندك، وقد تحتاجين تعديلًا حسب إصدارك.
- في حالة `Not Ready` أو `Accelerometer Timeout`: أوقفي التجربة، استخدمي Lite وأعيدي تشغيل الجلسة عند إصلاح السبب.
