#!/usr/bin/env python3
"""Project 1: waypoint mission on a short indoor challenge. No loop/AI/vision.
Gazebo ENU x east, y north, z up; MAVSDK mission altitudes relative to HOME.
This script will never force-arm or bypass PX4 preflight checks.
"""
import asyncio
import json
import math
import time
from pathlib import Path
from mavsdk_grpc import System
from mavsdk_grpc.mission import MissionItem, MissionPlan

CFG=json.loads((Path(__file__).resolve().parent/'track_config.json').read_text())
LAT0=CFG['origin_gps']['latitude_deg']
LON0=CFG['origin_gps']['longitude_deg']
R=6378137.0
NAN=float('nan')


def gps(x,y):
    return (LAT0 + math.degrees(y/R),
            LON0 + math.degrees(x/(R*math.cos(math.radians(LAT0)))))


def xy_dist(lat1,lon1,lat2,lon2):
    return math.hypot(math.radians(lat1-lat2)*R,
                      math.radians(lon1-lon2)*R*math.cos(math.radians(lat2)))


def build_route():
    """Approach -> centre -> exit for each gate; shifts altitude between gates."""
    points=[(6.,0.,2.1)]
    for i,g in enumerate(CFG['gates']):
        x,y,z=g['x_m'],g['y_m'],g['z_m']
        # Approach 5m before, exit 4m after: same centre height for safe alignment.
        points.extend([(x-5,y,z),(x,y,z),(x+4,y,z)])
    points.extend([(79,0,2.4),(83,0,2.4)])
    # Safety: all points within visible safe flight corridor
    assert len(points)==18
    return points


def build_plan(points,speed):
    items=[]
    for i,(x,y,z) in enumerate(points):
        lat,lon=gps(x,y)
        last=i==len(points)-1
        items.append(MissionItem(lat,lon,z-CFG['start']['spawn_z'],speed,
               not last,NAN,NAN,MissionItem.CameraAction.NONE,
               NAN,NAN,0.50,NAN,NAN,MissionItem.VehicleAction.NONE))
    return MissionPlan(items)


async def first(stream):
    async for item in stream:return item
    raise RuntimeError('Telemetry stream ended')

async def ready_health(drone,timeout=90):
    async def check():
        async for h in drone.telemetry.health():
            if h.is_global_position_ok and h.is_home_position_ok:
                return True
    try:
        return await asyncio.wait_for(check(),timeout)
    except asyncio.TimeoutError:
        return False


async def telemetry(drone):
    try:
        while True:
            p=await first(drone.telemetry.position())
            v=await first(drone.telemetry.velocity_ned())
            b=await first(drone.telemetry.battery())
            print(f'TELEMETRY | Altitude: {p.relative_altitude_m:.2f}m | '
                  f'Speed: {math.hypot(v.north_m_s,v.east_m_s):.2f}m/s | '
                  f'Battery: {b.remaining_percent*100:.0f}%')
            await asyncio.sleep(2.5)
    except asyncio.CancelledError:
        pass
    except Exception as exc:
        print('Telemetry unavailable:',exc)


async def main():
    drone=System()
    points=build_route()
    print('PROJECT 1 - INDOOR CHALLENGE / 5 Gates / One-way Course')
    print('Connecting to PX4...')
    await drone.connect(system_address='udpin://0.0.0.0:14540')
    async def connected():
        async for s in drone.core.connection_state():
            if s.is_connected:return True
    await asyncio.wait_for(connected(),45)
    print('Connected! Waiting for GPS and HOME...')
    if not await ready_health(drone,90):
        print('GPS/HOME not ready. Check Gazebo/PX4/QGC; do NOT force arm.');return
    if await first(drone.telemetry.in_air()):
        print('Drone is airborne; land it before starting.');return
    p=await first(drone.telemetry.position())
    if xy_dist(p.latitude_deg,p.longitude_deg,LAT0,LON0)>5:
        print('Drone not on START pad: restart simulation.');return
    print('Uploading 18 mission items for 5 raised/offset gates...')
    await drone.mission.set_return_to_launch_after_mission(False)
    await drone.mission.upload_mission(build_plan(points,1.0))
    await drone.mission.set_current_mission_item(0)
    print('Mission uploaded. Review altitude and line in QGroundControl.')
    print('Make sure QGC says Ready To Fly, no IMU/attitude warnings, and simulator is running smoothly.')
    if input('Type START after checking QGC: ').strip().upper()!='START':
        print('Cancelled.');return
    if not await ready_health(drone,30):
        print('No healthy GPS/HOME; cancelled.');return
    if await first(drone.telemetry.in_air()):
        print('Already airborne; cancelled.');return
    print('Starting challenge...')
    await drone.action.arm()
    await drone.mission.start_mission()
    watcher=asyncio.create_task(telemetry(drone))
    ts=time.monotonic()
    try:
        # safe timeout for a ~90m 1m/s course plus climbing/maneuvering
        for i in range(280):
            if await drone.mission.is_mission_finished():break
            await asyncio.sleep(1)
        else:
            print('MISSION TIMEOUT - monitor in QGC and land safely.');return
        pos=await first(drone.telemetry.position())
        fl,fo=gps(CFG['finish']['x'],CFG['finish']['y'])
        dist=xy_dist(pos.latitude_deg,pos.longitude_deg,fl,fo)
        print(f'Mission finished. Distance to finish: {dist:.2f}m')
        if dist>3.0:
            print('Not at planned landing pad; inspect before landing.');return
        print('Landing at finish...')
        await drone.action.land()
        for i in range(90):
            if not await first(drone.telemetry.in_air()):
                print('LANDING CONFIRMED. Mission time:',round(time.monotonic()-ts,1),'s')
                print('Note: Waypoint success alone is not proof of crossing inside each gate.')
                return
            await asyncio.sleep(1)
        print('Landing not confirmed; check QGC.')
    finally:
        watcher.cancel();await asyncio.gather(watcher,return_exceptions=True)

if __name__=='__main__':
    try: asyncio.run(main())
    except Exception as exc:
        print('Mission stopped:',str(exc))
        print('Check QGroundControl, PX4 and Gazebo. Never force arm.')
