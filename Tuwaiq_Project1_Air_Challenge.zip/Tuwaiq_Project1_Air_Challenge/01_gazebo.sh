#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-lite}"
case "$MODE" in lite) WORLD="$DIR/project1_indoor_lite.sdf";; full) WORLD="$DIR/project1_indoor_full.sdf";; *) echo 'Usage: bash 01_gazebo.sh [lite|full]';exit 2;; esac
export GZ_SIM_RESOURCE_PATH="$DIR:$HOME/PX4-Autopilot/Tools/simulation/gz/models:${GZ_SIM_RESOURCE_PATH:-}"
echo "Opening PROJECT 1 indoor arena [$MODE]"
gz sim -r "$WORLD"
